#define PEERID_PREFIX             "-TR242Z-"
#define USERAGENT_PREFIX          "2.42+"
#define SVN_REVISION              "13094"
#define SVN_REVISION_NUM          13094
#define SHORT_VERSION_STRING      "2.42+"
#define LONG_VERSION_STRING       "2.42+ (13094)"
#define VERSION_STRING_INFOPLIST  2.42+
#define MAJOR_VERSION             2
#define MINOR_VERSION             42
#define TR_NIGHTLY_RELEASE        1
